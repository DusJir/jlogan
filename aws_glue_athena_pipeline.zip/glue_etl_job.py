import sys
import re
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.utils import getResolvedOptions
from pyspark.sql.functions import col

args = getResolvedOptions(sys.argv, ['JOB_NAME'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = glueContext.create_job(args['JOB_NAME'])

input_path = "s3://your-bucket/raw/"
output_path = "s3://your-bucket/cleaned/"

df = spark.read.parquet(input_path)

struct_fields = df.schema["details"].dataType

def sanitize_field_name(name):
    return re.sub(r"[^a-zA-Z0-9_]", "_", name)

renamed_fields = [
    col(f"details.`{f.name}`").alias(sanitize_field_name(f.name))
    for f in struct_fields
]

flattened_df = df.select(
    *[col(c) for c in df.columns if c != "details"],
    *renamed_fields
).drop("details")

spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
flattened_df.repartition("event_date").write.mode("overwrite").partitionBy("event_date").option("compression", "snappy").parquet(output_path)

job.commit()
print("Sanitized data written to:", output_path)