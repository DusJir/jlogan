#!/bin/bash

aws glue create-trigger \
    --name trigger-raw-crawler-to-job \
    --type CONDITIONAL \
    --actions '[{"JobName":"sanitize-job"}]' \
    --predicate '{"Conditions":[{"CrawlerName":"raw-data-crawler","State":"SUCCEEDED"}]}' \
    --start-on-creation

aws glue create-trigger \
    --name trigger-job-to-clean-crawler \
    --type CONDITIONAL \
    --actions '[{"CrawlerName":"clean-data-crawler"}]' \
    --predicate '{"Conditions":[{"JobName":"sanitize-job","State":"SUCCEEDED"}]}' \
    --start-on-creation