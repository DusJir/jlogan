-- Basic Query
SELECT * FROM your_database.cleaned_table WHERE event_date = '2025-03-17';

-- Create View
CREATE OR REPLACE VIEW your_database.cleaned_view AS
SELECT sanitized_id, sanitized_name, event_date
FROM your_database.cleaned_table
WHERE sanitized_name IS NOT NULL;

-- CTAS Example
CREATE TABLE your_database.cleaned_ctas_table
WITH (
    format = 'PARQUET',
    external_location = 's3://your-bucket/cleaned_ctas/',
    partitioned_by = ARRAY['event_date']
) AS
SELECT * FROM your_database.cleaned_table;

-- Repair Partitions
MSCK REPAIR TABLE your_database.cleaned_table;