# AWS Glue + Athena Data Sanitization Pipeline

This package contains a full pipeline setup to:
- Sanitize problematic struct fields in S3 Parquet data.
- Automate Glue Crawlers, Glue Jobs, and Athena optimization.
- Handle everything inside a single S3 bucket with raw/cleaned prefixes.
- Optimize Glue and Athena for cost and performance.

---

## Pipeline Overview

1. Raw Parquet files land in `s3://your-bucket/raw/`
2. **Crawler 1** detects new data and triggers the Glue ETL job.
3. **Glue ETL Job** sanitizes struct field names and writes to `s3://your-bucket/cleaned/`
4. **Crawler 2** registers the cleaned data to Glue Catalog.
5. Athena queries optimized cleaned data.
6. Lifecycle rule auto-cleans or archives `raw/` data after X days.

---

## Files Included
- `glue_etl_job.py`: Glue ETL Job script.
- `lifecycle.json`: S3 lifecycle rule JSON.
- `create_triggers.sh`: CLI script to create Glue triggers.
- `athena_queries.sql`: Athena queries and view/CTAS examples.
- `iam_policy.json`: IAM policy for Glue job role.